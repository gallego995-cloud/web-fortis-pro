import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Products from '@/components/Products';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import { Toaster } from '@/components/ui/toaster';

function App() {
  return (
    <>
      <Helmet>
        <title>Fortis Pro - Soluciones Industriales Profesionales</title>
        <meta name="description" content="Fortis Pro ofrece máquinas de roscado eléctrica, máquinas de soldar láser y máquinas de corte láser de alta calidad para aplicaciones industriales profesionales." />
      </Helmet>
      <div className="min-h-screen bg-black">
        <Header />
        <Hero />
        <Products />
        <Contact />
        <Footer />
        <WhatsAppButton />
        <Toaster />
      </div>
    </>
  );
}

export default App;