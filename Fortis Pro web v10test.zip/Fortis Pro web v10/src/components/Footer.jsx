import React from 'react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-black border-t border-gray-800 py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img
              src="https://horizons-cdn.hostinger.com/28d4c8f3-ff9b-4123-a900-b26930f41014/9cf5406eec41cec3f6ddf47e9a6aa388.png"
              alt="Fortis Pro logo"
              className="h-8 w-auto"
            />
            <span className="text-gray-400">© {currentYear} Fortis Pro. Todos los derechos reservados.</span>
          </div>
          <div className="flex items-center gap-6">
            <a href="mailto:fortispro@fortispro.es" className="text-gray-400 hover:text-[#FF6600] transition-colors duration-300">
              fortispro@fortispro.es
            </a>
            <span className="text-gray-600">|</span>
            <span className="text-gray-400">Arenys de Munt</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;