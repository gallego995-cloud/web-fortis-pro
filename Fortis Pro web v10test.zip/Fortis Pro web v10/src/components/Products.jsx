import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Zap, Flame, Scissors } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ProductCard = ({ title, description, icon: Icon, image, delay }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const { toast } = useToast();

  const handleLearnMore = () => {
    toast({
      title: "Información del producto",
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
      transition={{ duration: 0.6, delay }}
      className="bg-gradient-to-br from-gray-900 to-black border border-gray-800 rounded-xl overflow-hidden hover:border-[#FF6600] transition-all duration-300 group"
    >
      <div className="relative h-64 overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
        <div className="absolute top-4 right-4 bg-[#FF6600] p-3 rounded-full">
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-2xl font-bold text-white mb-3">{title}</h3>
        <p className="text-gray-400 mb-6">{description}</p>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleLearnMore}
          className="w-full bg-[#FF6600] hover:bg-[#FF7700] text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-[#FF6600]/50"
        >
          Más Información
        </motion.button>
      </div>
    </motion.div>
  );
};

const Products = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const products = [
    {
      title: "Máquinas de Roscado Eléctrica",
      description: "Equipos de alta precisión para roscado eléctrico profesional con tecnología de última generación.",
      icon: Zap,
      image: "https://horizons-cdn.hostinger.com/28d4c8f3-ff9b-4123-a900-b26930f41014/596ad8a40d064d3545c7581c21ef6824.jpg",
      delay: 0.2
    },
    {
      title: "Máquinas de Soldar Láser",
      description: "Tecnología láser avanzada para soldadura precisa y eficiente en aplicaciones industriales.",
      icon: Flame,
      image: "https://horizons-cdn.hostinger.com/28d4c8f3-ff9b-4123-a900-b26930f41014/596ad8a40d064d3545c7581c21ef6824.jpg",
      delay: 0.4
    },
    {
      title: "Máquinas de Corte Láser",
      description: "Sistemas de corte láser de alta potencia para resultados profesionales y producción industrial.",
      icon: Scissors,
      image: "https://horizons-cdn.hostinger.com/28d4c8f3-ff9b-4123-a900-b26930f41014/cecf4d27b8b6499c5fd7df6e2a4c2c67.jpg",
      delay: 0.6
    }
  ];

  return (
    <section id="products" className="py-20 bg-black relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-black via-gray-900 to-black opacity-50"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Nuestros <span className="text-[#FF6600]">Productos</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Equipamiento industrial de calidad profesional diseñado para maximizar su productividad
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <ProductCard key={index} {...product} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;