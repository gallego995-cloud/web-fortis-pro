import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { MapPin, Mail, Phone, Loader2, Send } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ContactInfo = ({ icon: Icon, title, content, delay }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: -30 }}
      animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -30 }}
      transition={{ duration: 0.6, delay }}
      className="flex items-start gap-4 p-6 bg-gradient-to-br from-gray-900 to-black border border-gray-800 rounded-lg hover:border-[#FF6600] transition-all duration-300 group"
    >
      <div className="bg-[#FF6600] p-3 rounded-full group-hover:scale-110 transition-transform duration-300">
        <Icon className="w-6 h-6 text-white" />
      </div>
      <div>
        <h3 className="text-white font-semibold text-lg mb-1">{title}</h3>
        <p className="text-gray-400">{content}</p>
      </div>
    </motion.div>
  );
};

const Contact = () => {
  const ref = useRef(null);
  const formRef = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    const formData = new FormData(e.target);

    try {
      const response = await fetch("https://formsubmit.co/ajax/fortispro@fortispro.es", {
        method: "POST",
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(Object.fromEntries(formData))
      });

      if (response.ok) {
        toast({
          title: "¡Mensaje enviado con éxito!",
          description: "Nos pondremos en contacto contigo a la brevedad.",
          className: "bg-green-600 text-white border-none",
        });
        formRef.current?.reset();
      } else {
        throw new Error('Error al enviar el formulario');
      }
    } catch (error) {
      console.error(error);
      toast({
        title: "Error de envío",
        description: "Hubo un problema al enviar tu mensaje. Por favor intenta nuevamente más tarde o contáctanos por WhatsApp.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: "Dirección",
      content: "Calle Victoriano 10, Arenys de Munt",
      delay: 0.2
    },
    {
      icon: Mail,
      title: "Email",
      content: "fortispro@fortispro.es",
      delay: 0.4
    },
    {
      icon: Phone,
      title: "Teléfono",
      content: "+34 691 586 953",
      delay: 0.6
    }
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-to-b from-black via-gray-900 to-black relative overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            <span className="text-[#FF6600]">Contacta</span> con Nosotros
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Estamos aquí para ayudarte con tus necesidades industriales
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Info */}
          <div className="space-y-6">
            {contactInfo.map((info, index) => (
              <ContactInfo key={index} {...info} />
            ))}
          </div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 30 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <form 
              ref={formRef} 
              onSubmit={handleSubmit} 
              className="bg-gradient-to-br from-gray-900 to-black border border-gray-800 rounded-xl p-8 space-y-6"
            >
              {/* FormSubmit Configuration Hidden Fields */}
              <input type="hidden" name="_subject" value="Nuevo contacto desde web Fortis Pro" />
              <input type="hidden" name="_template" value="table" />
              <input type="hidden" name="_captcha" value="false" />

              <div>
                <label htmlFor="name" className="block text-white font-medium mb-2">Nombre</label>
                <input
                  type="text"
                  id="name"
                  name="name" // Added name attribute
                  className="w-full bg-black border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-[#FF6600] focus:outline-none transition-colors duration-300"
                  placeholder="Tu nombre"
                  required
                  disabled={isSubmitting}
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-white font-medium mb-2">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email" // Added name attribute
                  className="w-full bg-black border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-[#FF6600] focus:outline-none transition-colors duration-300"
                  placeholder="tu@email.com"
                  required
                  disabled={isSubmitting}
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-white font-medium mb-2">Mensaje</label>
                <textarea
                  id="message"
                  name="message" // Added name attribute
                  rows="5"
                  className="w-full bg-black border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-[#FF6600] focus:outline-none transition-colors duration-300 resize-none"
                  placeholder="¿Cómo podemos ayudarte?"
                  required
                  disabled={isSubmitting}
                ></textarea>
              </div>
              <motion.button
                type="submit"
                disabled={isSubmitting}
                whileHover={!isSubmitting ? { scale: 1.02 } : {}}
                whileTap={!isSubmitting ? { scale: 0.98 } : {}}
                className={`w-full bg-[#FF6600] hover:bg-[#FF7700] text-white px-6 py-4 rounded-lg font-semibold text-lg transition-all duration-300 shadow-lg hover:shadow-[#FF6600]/50 flex items-center justify-center gap-2 ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Enviar Mensaje
                  </>
                )}
              </motion.button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;